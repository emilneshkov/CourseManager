/**
* @author Emil Neshkov
* @idnumber 0MI0600506
* @compiler VC
**/
#include <iostream>
#include "CourseManagerApp.h"

int main()
{
	CourseManagerApp app;

	app.run();
}

